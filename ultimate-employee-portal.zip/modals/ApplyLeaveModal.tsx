import React, { useState, useRef, useEffect } from 'react';
import { XIcon } from '../components/icons/FeatherIcons';

// Since flatpickr is loaded from a CDN, we declare its type.
declare var flatpickr: any;

interface ApplyLeaveModalProps {
    onClose: () => void;
    onSubmit: (leaveRequest: { type: string; startDate: string; endDate: string; reason: string; }) => void;
}

const ApplyLeaveModal: React.FC<ApplyLeaveModalProps> = ({ onClose, onSubmit }) => {
    const [type, setType] = useState('Annual');
    const [reason, setReason] = useState('');
    const startDateRef = useRef<HTMLInputElement>(null);
    const endDateRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        let startPicker: any, endPicker: any;
        if (startDateRef.current) {
            startPicker = flatpickr(startDateRef.current, {
                altInput: true,
                altFormat: "F j, Y",
                dateFormat: "Y-m-d",
                onChange: function(selectedDates: Date[]) {
                    if (endPicker && selectedDates[0]) {
                        endPicker.set('minDate', selectedDates[0]);
                    }
                },
            });
        }
        if (endDateRef.current) {
            endPicker = flatpickr(endDateRef.current, {
                altInput: true,
                altFormat: "F j, Y",
                dateFormat: "Y-m-d",
            });
        }
        return () => {
            startPicker?.destroy();
            endPicker?.destroy();
        };
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const startDate = startDateRef.current?.value || '';
        const endDate = endDateRef.current?.value || '';
        if (startDate && endDate) {
            onSubmit({ type, startDate, endDate, reason });
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-[var(--bg-card)] rounded-2xl w-full max-w-lg border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Apply for Leave</h2>
                    <button type="button" onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="leave-type" className="block text-sm font-medium mb-1 text-gray-300">Leave Type</label>
                        <select id="leave-type" value={type} onChange={e => setType(e.target.value)} className="form-input w-full p-2 rounded text-white">
                            <option>Annual</option>
                            <option>Sick</option>
                            <option>Personal</option>
                            <option>Unpaid</option>
                        </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="start-date" className="block text-sm font-medium mb-1 text-gray-300">Start Date</label>
                            <input ref={startDateRef} id="start-date" type="text" placeholder="Select start date" required className="form-input w-full p-2 rounded text-white"/>
                        </div>
                        <div>
                            <label htmlFor="end-date" className="block text-sm font-medium mb-1 text-gray-300">End Date</label>
                            <input ref={endDateRef} id="end-date" type="text" placeholder="Select end date" required className="form-input w-full p-2 rounded text-white"/>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="leave-reason" className="block text-sm font-medium mb-1 text-gray-300">Reason (Optional)</label>
                        <textarea id="leave-reason" value={reason} onChange={e => setReason(e.target.value)} rows={3} placeholder="Briefly state the reason for your leave." className="form-input w-full p-2 rounded text-white"></textarea>
                    </div>
                </div>
                <div className="flex justify-end gap-4 mt-6">
                    <button type="button" onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                    <button type="submit" className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-2 px-4 rounded-lg">Submit Request</button>
                </div>
            </form>
        </div>
    );
};

export default ApplyLeaveModal;
