
import React, { useState, useRef, useCallback } from 'react';
import type { SarahMessage } from '../types';
import { XIcon, ZapIcon, PaperclipIcon, MicIcon, SendIcon } from '../components/icons/FeatherIcons';
import { generateContentStream } from '../services/geminiService';

interface AskSarahModalProps {
    onClose: () => void;
}

const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = (error) => reject(error);
    });

const AskSarahModal: React.FC<AskSarahModalProps> = ({ onClose }) => {
    const [messages, setMessages] = useState<SarahMessage[]>([
        { sender: 'sarah', text: "Hi! I'm SARAH, your personal assistant. How can I help?" }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [image, setImage] = useState<{ file: File; mimeType: string; base64: string; preview: string } | null>(null);
    const chatAreaRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleSendMessage = useCallback(async (e?: React.FormEvent<HTMLFormElement>) => {
        if(e) e.preventDefault();
        const currentInput = input.trim();
        if (!currentInput && !image) return;

        setIsLoading(true);
        const userMessage: SarahMessage = {
            sender: 'user',
            text: currentInput,
            ...(image && { imagePreview: image.preview })
        };
        setMessages(prev => [...prev, userMessage, { sender: 'loading', text: '' }]);
        setInput('');
        setImage(null);
        
        try {
            const stream = await generateContentStream(currentInput, image ? { inlineData: { mimeType: image.mimeType, data: image.base64 } } : undefined);

            let streamedText = '';
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = { sender: 'sarah', text: '' };
                return newMessages;
            });

            for await (const chunk of stream) {
                streamedText += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { sender: 'sarah', text: streamedText };
                    return newMessages;
                });
                if (chatAreaRef.current) {
                    chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
                }
            }

        } catch (error) {
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = { sender: 'sarah', text: 'Sorry, I encountered an error. Please try again.' };
                return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    }, [input, image]);
    
    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const base64 = await fileToBase64(file);
            const preview = URL.createObjectURL(file);
            setImage({ file, mimeType: file.type, base64, preview });
        }
    };

    const suggestions = ["What are today's top tasks?", "Summarize yesterday's sales.", "Look up iPhone 15 specs."];

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-2xl h-[80vh] flex flex-col border border-[var(--black-tertiary)] shadow-2xl">
                <div className="flex items-center justify-between p-4 border-b border-[var(--gray-dark)]">
                    <h3 className="text-lg font-bold text-white">Ask SARAH</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">
                        <XIcon className="w-6 h-6" />
                    </button>
                </div>
                <div ref={chatAreaRef} className="flex-1 p-6 overflow-y-auto space-y-6 custom-scrollbar">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-start space-x-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                             {msg.sender !== 'user' && (
                                <div className={`p-2 rounded-full flex-shrink-0 ${msg.sender === 'sarah' ? 'bg-[var(--primary-orange)]' : 'bg-gray-600'}`}>
                                    <ZapIcon className="w-5 h-5 text-white" />
                                </div>
                             )}
                            <div className={`p-3 rounded-lg max-w-lg ${msg.sender === 'user' ? 'bg-[var(--bg-tertiary)]' : 'bg-[var(--bg-secondary)]'}`}>
                                {msg.sender === 'loading' ? (
                                    <div className="flex items-center space-x-2">
                                        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                                        <div className="w-2 h-2 bg-white rounded-full animate-pulse delay-200"></div>
                                        <div className="w-2 h-2 bg-white rounded-full animate-pulse delay-400"></div>
                                    </div>
                                ) : (
                                    <>
                                        {msg.imagePreview && <img src={msg.imagePreview} alt="upload preview" className="rounded-lg mb-2 max-h-48" />}
                                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                    </>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t border-[var(--gray-dark)]">
                    <div className="flex items-center space-x-2 mb-2">
                        {suggestions.map(s => (
                            <button key={s} onClick={() => { setInput(s); }} className="text-xs bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] px-3 py-1 rounded-full">{s}</button>
                        ))}
                    </div>
                    {image && (
                        <div className="mb-2 flex items-center justify-between bg-[var(--bg-tertiary)] p-2 rounded-lg">
                            <div className="flex items-center gap-2">
                               <img src={image.preview} alt="preview" className="h-10 w-10 rounded-md object-cover"/>
                               <p className="text-sm text-gray-300">{image.file.name}</p>
                            </div>
                            <button onClick={() => setImage(null)} className="text-gray-400 hover:text-white">
                                <XIcon className="w-4 h-4" />
                            </button>
                        </div>
                    )}
                    <form onSubmit={handleSendMessage} className="flex items-center space-x-3">
                        <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*"/>
                        <button type="button" onClick={() => fileInputRef.current?.click()} className="text-gray-400 hover:text-white" aria-label="Attach image">
                            <PaperclipIcon />
                        </button>
                        <button type="button" className="text-gray-400 hover:text-white" aria-label="Use microphone">
                            <MicIcon />
                        </button>
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Ask me anything..."
                            className="w-full px-4 py-3 rounded-lg text-white placeholder-gray-500 focus:outline-none form-input"
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading} className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold p-3 rounded-lg disabled:opacity-50">
                            <SendIcon className="w-6 h-6" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AskSarahModal;
