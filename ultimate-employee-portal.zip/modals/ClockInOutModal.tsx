import React from 'react';
import { XIcon, ClockIcon } from '../components/icons/FeatherIcons';

interface ClockInOutModalProps {
    isClockedIn: boolean;
    onClose: () => void;
    onToggle: () => void;
}

const ClockInOutModal: React.FC<ClockInOutModalProps> = ({ isClockedIn, onClose, onToggle }) => {
    const actionText = isClockedIn ? 'Clock Out' : 'Clock In';
    const message = isClockedIn ? 'End your shift?' : 'Ready to start your shift?';

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-sm border border-[var(--black-tertiary)] shadow-2xl p-6 text-center">
                <div className="flex justify-end">
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <ClockIcon className="w-16 h-16 text-[var(--primary-orange)] mx-auto mb-4"/>
                <h2 className="text-xl font-bold text-white mb-2">{actionText}</h2>
                <p className="text-gray-300 mb-6">{message}</p>
                <div className="flex flex-col gap-3">
                    <button onClick={onToggle} className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-3 px-4 rounded-lg">
                        Confirm {actionText}
                    </button>
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                </div>
            </div>
        </div>
    );
};

export default ClockInOutModal;
