import React, { useState } from 'react';
import type { Employee } from '../types';
import { XIcon } from '../components/icons/FeatherIcons';

interface DelegateTaskModalProps {
    taskId: number;
    employees: Employee[];
    onClose: () => void;
    onDelegate: (taskId: number, employeeName: string) => void;
}

const DelegateTaskModal: React.FC<DelegateTaskModalProps> = ({ taskId, employees, onClose, onDelegate }) => {
    const [selectedEmployee, setSelectedEmployee] = useState(employees[0]?.name || '');

    const handleAssign = () => {
        if (selectedEmployee) {
            onDelegate(taskId, selectedEmployee);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-md border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Delegate Task</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <select 
                    value={selectedEmployee} 
                    onChange={e => setSelectedEmployee(e.target.value)}
                    className="form-input w-full p-2 rounded text-white"
                >
                    {employees.map(emp => <option key={emp.id} value={emp.name}>{emp.name} ({emp.role})</option>)}
                </select>
                <button onClick={handleAssign} className="w-full bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] py-2 rounded mt-4 text-white font-bold">Assign Task</button>
                <button onClick={onClose} className="mt-2 w-full bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] py-2 rounded-lg text-white">Cancel</button>
            </div>
        </div>
    );
};

export default DelegateTaskModal;
