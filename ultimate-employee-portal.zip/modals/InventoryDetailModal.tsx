import React from 'react';
import type { InventoryItem } from '../types';
import { XIcon } from '../components/icons/FeatherIcons';

interface InventoryDetailModalProps {
    item: InventoryItem;
    onClose: () => void;
}

const InventoryDetailModal: React.FC<InventoryDetailModalProps> = ({ item, onClose }) => {
    const formatKey = (key: string) => {
        return key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-lg border border-[var(--black-tertiary)] shadow-2xl">
                <div className="flex justify-between items-center p-6 border-b border-[var(--gray-dark)]">
                    <h2 className="text-xl font-bold text-white">{item.name} - Details</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div className="p-6 max-h-[60vh] overflow-y-auto custom-scrollbar">
                    <div className="space-y-2 text-sm">
                        {Object.entries(item).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-center p-3 rounded-md bg-[var(--bg-tertiary)]">
                                <span className="font-semibold text-gray-300">{formatKey(key)}:</span>
                                <span className="text-white text-right">{value}</span>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="flex justify-end p-6 border-t border-[var(--gray-dark)]">
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Close</button>
                </div>
            </div>
        </div>
    );
};

export default InventoryDetailModal;
