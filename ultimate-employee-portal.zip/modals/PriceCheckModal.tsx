import React, { useState } from 'react';
import { XIcon } from '../components/icons/FeatherIcons';
import type { InventoryItem } from '../types';

interface PriceCheckModalProps {
    inventory: InventoryItem[];
    onClose: () => void;
}

const PriceCheckModal: React.FC<PriceCheckModalProps> = ({ inventory, onClose }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const handlePriceCheck = (e: React.FormEvent) => {
        e.preventDefault();
        const term = searchTerm.toLowerCase();
        const foundItem = inventory.find(
            item => item.name.toLowerCase().includes(term) || item.product_code.toLowerCase() === term
        );

        if (foundItem) {
            // Mocking price - let's say price is 2.5x the min order qty as a dummy logic
            const price = foundItem.min_order_quantity * 2.5 + 9.99;
            setResult(`'${foundItem.name}' is $${price.toFixed(2)}.`);
        } else {
            setResult(`Product '${searchTerm}' not found in inventory.`);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-md border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Price Check</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <form onSubmit={handlePriceCheck}>
                    <label htmlFor="price-check-input" className="block text-sm font-medium mb-1 text-gray-300">Product Name or Code</label>
                    <div className="flex gap-2">
                        <input
                            type="text"
                            id="price-check-input"
                            value={searchTerm}
                            onChange={e => { setSearchTerm(e.target.value); setResult(null); }}
                            placeholder="e.g., iPhone 15 or ACC001"
                            required
                            className="form-input w-full p-2 rounded text-white"
                        />
                        <button type="submit" className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold px-4 rounded-lg">Check</button>
                    </div>
                </form>
                {result && (
                    <div className="mt-4 p-3 bg-[var(--bg-tertiary)] rounded-lg text-center text-white">
                        {result}
                    </div>
                )}
                 <div className="flex justify-end mt-6">
                    <button type="button" onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Close</button>
                </div>
            </div>
        </div>
    );
};

export default PriceCheckModal;
