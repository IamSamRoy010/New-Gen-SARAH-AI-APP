import React, { useState } from 'react';
import { XIcon } from '../components/icons/FeatherIcons';

interface ReportIssueModalProps {
    onClose: () => void;
    onSubmit: (issue: { type: string; location: string; description: string }) => void;
}

const ReportIssueModal: React.FC<ReportIssueModalProps> = ({ onClose, onSubmit }) => {
    const [type, setType] = useState('Spill');
    const [location, setLocation] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit({ type, location, description });
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <form onSubmit={handleSubmit} className="bg-[var(--bg-card)] rounded-2xl w-full max-w-lg border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Report an Issue</h2>
                    <button type="button" onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="issue-type" className="block text-sm font-medium mb-1 text-gray-300">Issue Type</label>
                        <select id="issue-type" value={type} onChange={e => setType(e.target.value)} className="form-input w-full p-2 rounded text-white">
                            <option>Spill</option>
                            <option>Broken Equipment</option>
                            <option>Safety Hazard</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="issue-location" className="block text-sm font-medium mb-1 text-gray-300">Location</label>
                        <input type="text" id="issue-location" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g., Aisle 5, Electronics section" required className="form-input w-full p-2 rounded text-white"/>
                    </div>
                    <div>
                        <label htmlFor="issue-description" className="block text-sm font-medium mb-1 text-gray-300">Description</label>
                        <textarea id="issue-description" value={description} onChange={e => setDescription(e.target.value)} rows={4} placeholder="Provide a brief description of the issue." required className="form-input w-full p-2 rounded text-white"></textarea>
                    </div>
                </div>
                <div className="flex justify-end gap-4 mt-6">
                    <button type="button" onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                    <button type="submit" className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-2 px-4 rounded-lg">Submit Report</button>
                </div>
            </form>
        </div>
    );
};

export default ReportIssueModal;
