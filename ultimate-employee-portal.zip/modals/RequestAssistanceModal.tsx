import React from 'react';
import { XIcon } from '../components/icons/FeatherIcons';

interface RequestAssistanceModalProps {
    onClose: () => void;
    onRequest: (type: string) => void;
}

const RequestAssistanceModal: React.FC<RequestAssistanceModalProps> = ({ onClose, onRequest }) => {
    const assistanceTypes = [
        { type: 'Manager', description: 'Request a manager for customer issues or approvals.' },
        { type: 'Janitorial', description: 'Request cleaning for a spill or other mess.' },
        { type: 'Security', description: 'Alert security for a potential theft or safety concern.' },
    ];

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-lg border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-white">Request Assistance</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div className="space-y-4">
                    {assistanceTypes.map(({ type, description }) => (
                        <button key={type} onClick={() => onRequest(type)} className="w-full text-left p-4 bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] rounded-lg">
                            <p className="font-bold text-white">{type}</p>
                            <p className="text-sm text-gray-400">{description}</p>
                        </button>
                    ))}
                </div>
                <div className="flex justify-end mt-6">
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                </div>
            </div>
        </div>
    );
};

export default RequestAssistanceModal;
