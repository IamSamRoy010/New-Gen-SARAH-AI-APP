import React, { useState } from 'react';
import type { Shift, Employee } from '../types';
import { XIcon } from '../components/icons/FeatherIcons';

interface RequestSubModalProps {
    shift: Shift;
    currentUser: string;
    employees: Employee[];
    onClose: () => void;
    onSubRequest: (shiftId: string, fromEmployee: string, toEmployee: string) => void;
}

const RequestSubModal: React.FC<RequestSubModalProps> = ({ shift, currentUser, employees, onClose, onSubRequest }) => {
    const availableEmployees = employees.filter(e => e.name !== currentUser);
    const [selectedEmployee, setSelectedEmployee] = useState(availableEmployees[0]?.name || '');

    const handleRequest = () => {
        if (selectedEmployee) {
            onSubRequest(shift.id, currentUser, selectedEmployee);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-md border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Request Shift Cover</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div className="bg-[var(--bg-tertiary)] p-3 rounded-lg mb-4 text-sm">
                    <p>You are requesting cover for:</p>
                    <p className="font-bold text-white">{shift.title} on {shift.day}</p>
                    <p className="text-gray-300">{shift.start}:00 - {shift.end}:00</p>
                </div>
                <label htmlFor="employee-select" className="block text-sm font-medium text-gray-300 mb-2">Select a coworker to send the request to:</label>
                <select
                    id="employee-select"
                    value={selectedEmployee} 
                    onChange={e => setSelectedEmployee(e.target.value)}
                    className="form-input w-full p-2 rounded text-white"
                >
                    {availableEmployees.map(emp => <option key={emp.id} value={emp.name}>{emp.name}</option>)}
                </select>
                <div className="flex justify-end gap-4 mt-6">
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                    <button onClick={handleRequest} className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">Send Request</button>
                </div>
            </div>
        </div>
    );
};

export default RequestSubModal;
