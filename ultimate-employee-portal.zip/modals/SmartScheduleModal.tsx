import React, { useState } from 'react';
import type { Schedule, Employee } from '../types';
import { XIcon } from '../components/icons/FeatherIcons';

interface SmartScheduleModalProps {
    schedules: Schedule;
    employees: Employee[];
    onClose: () => void;
}

type SmartTab = 'slot-finder' | 'pay-optimizer';

const BestSlotFinder: React.FC<{ schedules: Schedule; employees: Employee[] }> = ({ schedules, employees }) => {
    const [selectedEmployees, setSelectedEmployees] = useState<string[]>(['Sarah Johnson']);
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const timeSlots = Array.from({ length: 15 }, (_, i) => i + 8);

    const handleEmployeeToggle = (name: string) => {
        setSelectedEmployees(prev =>
            prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
        );
    };

    const isSlotAvailable = (hour: number, day: string): boolean => {
        if (selectedEmployees.length === 0) return true;
        return selectedEmployees.every(name => {
            const schedule = schedules[name] || [];
            return !schedule.some(s => s.day === day && hour >= s.start && hour < s.end);
        });
    };

    return (
        <div>
            <h4 className="font-bold text-white mb-2">Select Coworkers to Find a Slot:</h4>
            <div className="flex flex-wrap gap-2 mb-4">
                {employees.map(emp => (
                    <button
                        key={emp.id}
                        onClick={() => handleEmployeeToggle(emp.name)}
                        className={`px-3 py-1 rounded-full text-sm ${selectedEmployees.includes(emp.name) ? 'bg-purple-600 text-white' : 'bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)]'}`}
                    >
                        {emp.name}
                    </button>
                ))}
            </div>
            <div className="grid grid-cols-6 text-center text-xs text-gray-400 font-bold border-b border-[var(--gray-dark)] pb-2">
                <div></div>
                {days.map(day => <div key={day}>{day}</div>)}
            </div>
            <div className="grid grid-cols-6 max-h-64 overflow-y-auto custom-scrollbar">
                <div className="text-right text-xs text-gray-500 pr-2 border-r border-[var(--gray-dark)]">
                    {timeSlots.map(hour => <div key={hour} className="h-8 flex items-center justify-end">{`${hour % 12 || 12}${hour < 12 ? 'am' : 'pm'}`}</div>)}
                </div>
                {days.map(day => (
                    <div key={day} className="border-r border-[var(--gray-dark)]">
                        {timeSlots.map(hour => {
                            const isAvailable = isSlotAvailable(hour, day);
                            return (
                                <div key={hour} className={`h-8 border-b border-dashed border-[var(--bg-tertiary)] ${isAvailable ? 'bg-green-500/20' : 'bg-red-500/20'}`}></div>
                            )
                        })}
                    </div>
                ))}
            </div>
             <p className="text-xs text-gray-400 mt-2">*Green slots indicate availability for all selected members.</p>
        </div>
    );
};

const PayOptimizer: React.FC = () => {
    // Mocked open shifts with earning potential factors
    const openShifts = [
      { id: 'os1', title: 'Morning Cover', day: 'Sat', start: 8, end: 12, payRate: 1.2, urgency: 1.1, rank: 0 },
      { id: 'os2', title: 'Evening Peak', day: 'Fri', start: 18, end: 22, payRate: 1.5, urgency: 1.3, rank: 0 },
      { id: 'os3', title: 'Lunch Rush', day: 'Wed', start: 11, end: 15, payRate: 1.1, urgency: 1.0, rank: 0 },
      { id: 'os4', title: 'Full Day', day: 'Sun', start: 9, end: 17, payRate: 1.8, urgency: 1.2, rank: 0 },
    ];
    
    openShifts.forEach(shift => {
        shift.rank = (shift.end - shift.start) * shift.payRate * shift.urgency;
    });

    const rankedShifts = openShifts.sort((a, b) => b.rank - a.rank);

    return (
        <div>
            <h4 className="font-bold text-white mb-4">Available Shifts Ranked by Earning Potential:</h4>
            <div className="space-y-3">
                {rankedShifts.map((shift, index) => (
                    <div key={shift.id} className="bg-[var(--bg-tertiary)] p-3 rounded-lg flex justify-between items-center">
                        <div>
                            <p className="font-bold text-white">{index + 1}. {shift.title} ({shift.day})</p>
                            <p className="text-sm text-gray-300">{shift.start}:00 - {shift.end}:00 ({shift.end - shift.start} hrs)</p>
                        </div>
                        <div className="text-right">
                             <button className="bg-green-600 hover:bg-green-700 text-white text-sm px-3 py-1 rounded-md">Claim Shift</button>
                             <p className="text-xs text-yellow-400 mt-1">Pay Boost: x{shift.payRate.toFixed(1)}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const SmartScheduleModal: React.FC<SmartScheduleModalProps> = ({ schedules, employees, onClose }) => {
    const [activeTab, setActiveTab] = useState<SmartTab>('slot-finder');

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-2xl border border-[var(--black-tertiary)] shadow-2xl">
                <div className="flex justify-between items-center p-6 border-b border-[var(--gray-dark)]">
                    <h2 className="text-xl font-bold text-white">Smart Scheduling</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon /></button>
                </div>

                <div className="p-6">
                    <div className="border-b border-[var(--gray-dark)] mb-4">
                        <nav className="-mb-px flex space-x-8">
                            <button onClick={() => setActiveTab('slot-finder')} className={`profile-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm border-transparent ${activeTab === 'slot-finder' ? 'active' : 'text-gray-400 hover:text-white'}`}>
                                Best Slot Finder
                            </button>
                            <button onClick={() => setActiveTab('pay-optimizer')} className={`profile-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm border-transparent ${activeTab === 'pay-optimizer' ? 'active' : 'text-gray-400 hover:text-white'}`}>
                                Pay Optimizer
                            </button>
                        </nav>
                    </div>

                    {activeTab === 'slot-finder' && <BestSlotFinder schedules={schedules} employees={employees} />}
                    {activeTab === 'pay-optimizer' && <PayOptimizer />}
                </div>

                <div className="flex justify-end p-6 border-t border-[var(--gray-dark)]">
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Close</button>
                </div>
            </div>
        </div>
    );
};

export default SmartScheduleModal;
