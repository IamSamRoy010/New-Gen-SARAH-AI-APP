import React, { useState } from 'react';
import type { Task } from '../types';
import { XIcon } from '../components/icons/FeatherIcons';

interface TaskUpdateModalProps {
    task: Task;
    onClose: () => void;
    onUpdate: (taskId: number, updates: { quantity?: number }) => void;
}

const TaskUpdateModal: React.FC<TaskUpdateModalProps> = ({ task, onClose, onUpdate }) => {
    const [quantity, setQuantity] = useState('');

    const handleSubmit = () => {
        const updates: { quantity?: number } = {};
        if (task.task_type === 'Inventory') {
            const numQuantity = parseInt(quantity, 10);
            if (!isNaN(numQuantity) && numQuantity > 0) {
                updates.quantity = numQuantity;
            } else {
                // maybe show an error
                return;
            }
        }
        onUpdate(task.id, updates);
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-md border border-[var(--black-tertiary)] shadow-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">{task.task_name}</h2>
                     <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                </div>
                <div>
                    <p className="text-sm text-gray-400 mb-4">{task.description}</p>
                    {task.task_type === 'Inventory' && (
                        <div>
                            <label htmlFor="quantity-updated" className="block text-sm font-medium mb-2">Quantity Restocked:</label>
                            <input
                                type="number"
                                id="quantity-updated"
                                value={quantity}
                                onChange={(e) => setQuantity(e.target.value)}
                                className="form-input w-full p-2 rounded"
                                placeholder="Enter number of items"
                            />
                        </div>
                    )}
                     {task.task_type !== 'Inventory' && (
                        <p className="text-gray-300">Mark this task as complete?</p>
                     )}
                </div>
                <div className="flex justify-end gap-4 mt-6">
                    <button onClick={onClose} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Cancel</button>
                    <button onClick={handleSubmit} className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-2 px-4 rounded-lg">Submit Update</button>
                </div>
            </div>
        </div>
    );
};

export default TaskUpdateModal;
