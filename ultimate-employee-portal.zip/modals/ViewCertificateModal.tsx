
import React from 'react';
import type { TrainingModule } from '../types';
import { XIcon, AwardIcon, DownloadIcon, PrinterIcon, Share2Icon } from '../components/icons/FeatherIcons';

interface ViewCertificateModalProps {
    module: TrainingModule;
    onClose: () => void;
}

const ViewCertificateModal: React.FC<ViewCertificateModalProps> = ({ module, onClose }) => {
    // Hardcoded for the current logged-in user
    const employeeName = "Sarah Johnson";
    const employeeId = "EMP12345";

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-card)] rounded-2xl w-full max-w-4xl border border-[var(--black-tertiary)] shadow-2xl flex flex-col">
                <div className="flex justify-between items-center p-4 border-b border-[var(--gray-dark)]">
                    <h2 className="text-lg font-bold text-white">Certificate of Completion</h2>
                    <div className="flex items-center gap-2">
                        <button onClick={() => alert('Download PDF functionality coming soon.')} className="p-2 rounded-lg bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] text-gray-300" title="Download as PDF">
                            <DownloadIcon className="w-5 h-5"/>
                        </button>
                        <button onClick={() => alert('Print functionality coming soon.')} className="p-2 rounded-lg bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] text-gray-300" title="Print Certificate">
                            <PrinterIcon className="w-5 h-5"/>
                        </button>
                        <button onClick={() => alert('Share functionality coming soon.')} className="p-2 rounded-lg bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] text-gray-300" title="Share">
                            <Share2Icon className="w-5 h-5"/>
                        </button>
                        <button onClick={onClose} className="text-gray-400 hover:text-white"><XIcon/></button>
                    </div>
                </div>

                <div className="p-8 md:p-12 bg-[var(--bg-secondary)] m-4 rounded-lg">
                    <div className="border-4 border-[var(--primary-orange)] p-8 relative aspect-[1.414/1] flex flex-col items-center justify-center text-center">
                        <div className="absolute top-4 right-4 text-center">
                            <AwardIcon className="w-16 h-16 text-yellow-400 mx-auto"/>
                            <p className="text-xs font-bold text-yellow-500">OFFICIAL SEAL</p>
                        </div>
                        <p className="text-xl text-gray-300 font-light tracking-widest">CERTIFICATE OF COMPLETION</p>
                        <p className="text-gray-400 mt-4">This is to certify that</p>
                        <h1 className="text-4xl md:text-5xl font-bold text-white my-4">{employeeName}</h1>
                        <p className="text-gray-400">has successfully completed the training course</p>
                        <h2 className="text-2xl md:text-3xl font-semibold text-[var(--accent-orange)] my-3">{module.title}</h2>
                        <div className="flex gap-8 text-sm text-gray-300 mt-6">
                            <span>Score: <strong>{module.score}%</strong></span>
                            <span>Level: <strong>{module.level}</strong></span>
                        </div>
                        <div className="w-full border-t border-[var(--gray-dark)] mt-auto pt-4 flex justify-between items-end">
                            <div className="text-left text-xs text-gray-500">
                                <p><strong>Issued On:</strong> {module.completionDate}</p>
                                <p><strong>Certificate ID:</strong> {module.certificateId}</p>
                                <p><strong>Employee ID:</strong> {employeeId}</p>
                            </div>
                             <div className="text-center">
                                <p className="font-serif italic text-lg text-white">David Lee</p>
                                <p className="border-t-2 border-gray-400 text-xs text-gray-400 pt-1">Store Manager</p>
                            </div>
                            <div className="text-center">
                                <p className="font-serif italic text-lg text-white">{module.instructor}</p>
                                <p className="border-t-2 border-gray-400 text-xs text-gray-400 pt-1">Course Instructor</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ViewCertificateModal;
