
import React, { useEffect, useRef } from 'react';

const AnalyticsPage: React.FC = () => {
    const salesChartRef = useRef<HTMLCanvasElement>(null);
    const trafficChartRef = useRef<HTMLCanvasElement>(null);
    const footfallChartRef = useRef<HTMLCanvasElement>(null);
    const categorySalesChartRef = useRef<HTMLCanvasElement>(null);
    const chartInstancesRef = useRef<any[]>([]);

    useEffect(() => {
        if (typeof (window as any).Chart === 'undefined') return;
        const Chart = (window as any).Chart;

        const style = getComputedStyle(document.documentElement);
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: style.getPropertyValue('--text-secondary').trim(), font: { family: "'Inter', sans-serif" } } },
                title: { display: true, color: style.getPropertyValue('--text-primary').trim(), font: { size: 16, family: "'Inter', sans-serif" } }
            },
            scales: {
                x: { ticks: { color: style.getPropertyValue('--text-muted').trim() }, grid: { color: style.getPropertyValue('--gray-dark').trim() } },
                y: { ticks: { color: style.getPropertyValue('--text-muted').trim() }, grid: { color: style.getPropertyValue('--gray-dark').trim() } }
            }
        };

        const charts = [
            { ref: salesChartRef, type: 'bar', data: { labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], datasets: [{ label: 'Sales ($k)', data: [12, 19, 15, 17, 18], backgroundColor: style.getPropertyValue('--primary-orange').trim(), borderRadius: 4 }] }, title: 'Weekly Sales Performance' },
            { ref: trafficChartRef, type: 'line', data: { labels: ['Morning', 'Afternoon', 'Evening'], datasets: [{ label: 'Customer Traffic', data: [65, 59, 80], borderColor: style.getPropertyValue('--accent-orange').trim(), backgroundColor: style.getPropertyValue('--orange-subtle').trim(), fill: true, tension: 0.4 }] }, title: 'Customer Traffic by Time of Day' },
            { ref: footfallChartRef, type: 'line', data: { labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], datasets: [{ label: 'Customer Footfall', data: [250, 310, 280, 350, 410, 550, 480], borderColor: style.getPropertyValue('--orange-light').trim(), tension: 0.4 }] }, title: 'Weekly Customer Footfall' },
            { ref: categorySalesChartRef, type: 'doughnut', data: { labels: ['Electronics', 'Accessories', 'Services'], datasets: [{ label: 'Sales by Category', data: [55, 30, 15], backgroundColor: [style.getPropertyValue('--primary-orange').trim(), style.getPropertyValue('--accent-orange').trim(), style.getPropertyValue('--orange-light').trim()], borderColor: style.getPropertyValue('--bg-card').trim(), borderWidth: 4 }] }, title: 'Sales by Category' },
        ];
        
        charts.forEach(chartConfig => {
            if (chartConfig.ref.current) {
                const chartInstance = new Chart(chartConfig.ref.current, {
                    type: chartConfig.type,
                    data: chartConfig.data,
                    options: { ...chartOptions, plugins: { ...chartOptions.plugins, title: { ...chartOptions.plugins.title, text: chartConfig.title } } }
                });
                chartInstancesRef.current.push(chartInstance);
            }
        });

        return () => {
            chartInstancesRef.current.forEach(chart => chart.destroy());
            chartInstancesRef.current = [];
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">Performance Analytics</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-[var(--bg-card)] p-6 rounded-lg h-80"><canvas ref={salesChartRef}></canvas></div>
                <div className="bg-[var(--bg-card)] p-6 rounded-lg h-80"><canvas ref={trafficChartRef}></canvas></div>
                <div className="bg-[var(--bg-card)] p-6 rounded-lg h-80"><canvas ref={footfallChartRef}></canvas></div>
                <div className="bg-[var(--bg-card)] p-6 rounded-lg h-80"><canvas ref={categorySalesChartRef}></canvas></div>
            </div>
        </div>
    );
};

export default AnalyticsPage;
