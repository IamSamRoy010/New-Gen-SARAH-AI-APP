import React, { useState, useRef, useEffect } from 'react';
// FIX: Import ChatContact to use for type assertions.
import type { ChatDB, ChatContact } from '../types';
import { SendIcon } from '../components/icons/FeatherIcons';

interface ChatPageProps {
    chatDB: ChatDB;
    onSendMessage: (chatId: string, messageText: string) => void;
}

const SARAH_AVATAR = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiIgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCI+PHBhdGggZD0iTTAgMGgyNHYyNEgweiIgZmlsbD0ibm9uZSIvPjxwYXRoIGQ9Ik0xOS45MyAxMS4wOGMtMS4zMi00LjQyLTQuNDQtNS4xMy00LjQ0LTUuMTNzLjM0IDEuNTMtLjE1IDIuODljLS41IDIuMTktMi4zOCA0LjYxLTQuNDQgNi4zMy0yLjM0IDEuOTYtMy4zNSAyLjQ1LTMuMzUgMi40NXMxLjY4LS4zNCAyLjgzLTEuNjljMS4zMy0xLjU3IDEuNjctMy4yNSAxLjY3LTMuMjVzLTMuMTggMS44NS00LjkyIDUuMTRjLTEuNzUgMy4zMi0xLjQxIDUuNDYtMS40MSA1LjQ2czMuNDEtMS40NyA1LjQ0LTQuNDRjMS44MS0yLjY0IDIuMzgtNC4xNSAyLjM4LTQuMTVzMy45MyAyLjY3IDQuOTIgNS4xNGMxLjI0IDMuMDgtLjQyIDUuNTYtLjQyIDUuNTZzMS4xMy0zLjA4LS4xNi01LjU2Yy0xLjI0LTIuMzYtMy4xMy0zLjY5LTMuMTMtMy42OXMyLjU5LTEuNDQgNC45Mi0zLjM4YzIuMjYtMS44NiAzLjUzLTMuOTMgMy4zMy0zLjkzcy0xLjg1IDIuNTQtMy44NyAyLjE3Yy0yLjA5LS4zNy0zLjQyLTIuNTQtMy40Mi0yLjU0czIuNDMgMS4yMyAzLjkxIDQuMjV6Ii8+PC9zdmc+"; // Bot/AI icon

const ChatPage: React.FC<ChatPageProps> = ({ chatDB, onSendMessage }) => {
    const [activeChatId, setActiveChatId] = useState<string>('david');
    const [input, setInput] = useState('');
    const messageAreaRef = useRef<HTMLDivElement>(null);

    const messages = chatDB[activeChatId]?.messages || [];

    useEffect(() => {
        if(messageAreaRef.current) {
            messageAreaRef.current.scrollTop = messageAreaRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (input.trim()) {
            onSendMessage(activeChatId, input.trim());
            setInput('');
        }
    };

    const activeChat = chatDB[activeChatId];

    return (
        <div className="h-[calc(100vh-12rem)] flex space-x-4">
            <div className="w-1/4 bg-[var(--bg-card)] rounded-lg p-4 flex flex-col">
                <h3 className="font-bold text-white mb-4">Chats</h3>
                {Object.entries(chatDB).map(([id, chatData]) => {
                    // FIX: Cast chat data to the correct type to resolve 'unknown' type errors.
                    const chat = chatData as ChatContact;
                    return (
                        <button key={id} onClick={() => setActiveChatId(id)} className={`w-full text-left flex items-center space-x-3 p-2 rounded-lg ${id === activeChatId ? 'bg-[var(--bg-tertiary)]' : 'hover:bg-[var(--bg-tertiary)]'}`}>
                            {chat.avatar ? <img className="h-8 w-8 rounded-full" src={chat.avatar} alt=""/> : <div className="h-8 w-8 rounded-full bg-purple-600 flex items-center justify-center font-bold text-sm">{chat.name.substring(1,3)}</div>}
                            <div><p className="font-semibold text-white text-sm">{chat.name}</p><p className="text-xs text-gray-400 truncate">{chat.messages.slice(-1)[0]?.t || ''}</p></div>
                        </button>
                    );
                })}
            </div>
            <div className="w-3/4 bg-[var(--bg-card)] rounded-lg flex flex-col">
                {/* FIX: Cast activeChat to ChatContact to access its properties. */}
                <div className="p-4 border-b border-[var(--gray-dark)] flex justify-between items-center"><h3 className="font-bold text-white">{(activeChat as ChatContact).name}</h3></div>
                <div ref={messageAreaRef} className="flex-1 p-6 overflow-y-auto space-y-4 custom-scrollbar">
                    {messages.map((msg, index) => {
                        const isUser = msg.s === 'Sarah Johnson';
                        // FIX: Cast chat contact within .find() and its result to resolve 'unknown' type error.
                        const senderInfo = Object.values(chatDB).find(c => (c as ChatContact).name === msg.s) as ChatContact | undefined;
                        const avatarUrl = isUser 
                            ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=256'
                            : msg.s === 'SARAH'
                                ? SARAH_AVATAR
                                : senderInfo?.avatar || `https://picsum.photos/100/100?random=${index}`;

                        return (
                            <div key={index} className={`flex items-start space-x-3 max-w-lg ${isUser ? 'ml-auto flex-row-reverse space-x-reverse' : ''}`}>
                                <img className="h-8 w-8 rounded-full bg-black p-1" src={avatarUrl} alt=""/>
                                <div className={`p-3 rounded-lg ${isUser ? 'bg-[var(--primary-orange)]' : msg.s === 'SARAH' ? 'bg-purple-600' : 'bg-[var(--bg-tertiary)]'}`}>
                                    <p className="text-sm text-white whitespace-pre-wrap">{msg.t}</p>
                                </div>
                            </div>
                        )
                    })}
                </div>
                <div className="p-4 border-t border-[var(--gray-dark)]">
                    <form onSubmit={handleSend} className="flex items-center space-x-3">
                        <input type="text" value={input} onChange={e => setInput(e.target.value)} placeholder="Type a message..." className="w-full px-4 py-3 rounded-lg text-white placeholder-gray-500 focus:outline-none form-input"/>
                        <button type="submit" className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold p-3 rounded-lg"><SendIcon className="w-6 h-6"/></button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ChatPage;