import React, { useState, useEffect, useRef } from 'react';
import type { ModalType, Page, Task, ReorderRequest, TaskStatus, TaskPriority, Schedule, Employee, Shift } from '../types';
import { ClockIcon, AlertTriangleIcon, HelpCircleIcon, DollarSignIcon, CalendarIcon, InfoIcon, SettingsIcon, UsersIcon, ChevronsLeftIcon, ChevronsRightIcon, BrainCircuitIcon } from '../components/icons/FeatherIcons';

interface DashboardPageProps {
  tasks: Task[];
  reorderRequests: ReorderRequest[];
  openModal: (modal: ModalType) => void;
  navigate: (page: Page) => void;
  onTaskStatusChange: (taskId: number, status: TaskStatus) => void;
  onTaskPriorityChange: (taskId: number, priority: TaskPriority) => void;
  schedules: Schedule;
  employees: Employee[];
}

const TaskItem: React.FC<{ task: Task, openModal: (m: ModalType) => void, onStatusChange: (id: number, s: TaskStatus) => void, onPriorityChange: (id: number, p: TaskPriority) => void }> = ({ task, openModal, onStatusChange, onPriorityChange }) => {
    const [menuOpen, setMenuOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);
    const statusStyles = { 'Open': 'bg-green-500/20 text-green-400', 'Ongoing': 'bg-yellow-500/20 text-yellow-400', 'Completed': 'bg-blue-500/20 text-blue-400', 'Delayed': 'bg-red-500/20 text-red-400', 'De-prioritised': 'bg-gray-500/20 text-gray-400', 'Delegated': 'bg-purple-500/20 text-purple-400' };
    const priorityStyles = { 'High': 'bg-red-500', 'Medium': 'bg-yellow-500', 'Low': 'bg-green-500' };
    const availableStatuses = Object.keys(statusStyles) as TaskStatus[];
    const availablePriorities: TaskPriority[] = ['High', 'Medium', 'Low'];

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);
    
    const handleStatusChange = (status: TaskStatus) => {
        if (status === 'Delegated') {
            openModal({ type: 'delegate-task', taskId: task.id });
        } else {
            onStatusChange(task.id, status);
        }
        setMenuOpen(false);
    };

    const handlePriorityChange = (priority: TaskPriority) => {
        onPriorityChange(task.id, priority);
        setMenuOpen(false);
    };

    return (
         <div className="bg-[var(--bg-card)] p-4 rounded-lg flex items-center gap-4">
            <div className={`w-2 h-10 rounded-full ${priorityStyles[task.priority]}`}></div>
            <div className="flex-grow">
                <p className="font-semibold text-white">{task.task_name}</p>
                <p className="text-sm text-gray-400">{task.status === 'Delegated' && task.assignedTo ? `Delegated to: ${task.assignedTo}` : `Due: ${task.due_date}`}</p>
            </div>
            <div className="flex items-center gap-3">
                <div className="relative group">
                    <InfoIcon className="w-5 h-5 text-gray-400" />
                    <div className="absolute bottom-full mb-2 w-64 bg-black text-white text-xs rounded py-2 px-3 right-0 transform translate-x-1/2 z-10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                        {task.description}
                    </div>
                </div>
                <button onClick={() => openModal({type: 'task-update', taskId: task.id})} className="bg-blue-600 hover:bg-blue-700 text-white text-sm px-3 py-1 rounded-md">Update Progress</button>
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${statusStyles[task.status]}`}>{task.status}</span>
                <div className="relative" ref={menuRef}>
                    <button onClick={() => setMenuOpen(prev => !prev)} className="text-gray-400 hover:text-white"><SettingsIcon/></button>
                    {menuOpen && (
                        <div className="absolute right-0 top-8 w-48 bg-gray-900 border border-gray-700 rounded-lg shadow-lg z-10 py-1">
                            <div className="px-4 py-2 text-xs text-gray-400 font-semibold uppercase">Change Status</div>
                            {availableStatuses.map(status => 
                                <a key={status} href="#" onClick={(e) => { e.preventDefault(); handleStatusChange(status); }} className="block px-4 py-2 text-sm hover:bg-gray-700">{status}</a>
                            )}
                            <div className="border-t border-gray-700 my-1"></div>
                            <div className="px-4 py-2 text-xs text-gray-400 font-semibold uppercase">Set Priority</div>
                            {availablePriorities.map(priority => 
                                <a key={priority} href="#" onClick={(e) => { e.preventDefault(); handlePriorityChange(priority); }} className="flex items-center justify-between px-4 py-2 text-sm hover:bg-gray-700">
                                    <span>{priority}</span>
                                    <span className={`w-3 h-3 rounded-full ${priorityStyles[priority]}`}></span>
                                </a>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const TasksList: React.FC<{ tasks: Task[], openModal: (m: ModalType) => void, onTaskStatusChange: (id: number, s: TaskStatus) => void, onTaskPriorityChange: (id: number, p: TaskPriority) => void }> = ({ tasks, openModal, onTaskStatusChange, onTaskPriorityChange }) => (
    <div className="space-y-4">
        {tasks.length > 0 ? tasks.map(task => (
            <TaskItem key={task.id} task={task} openModal={openModal} onStatusChange={onTaskStatusChange} onPriorityChange={onTaskPriorityChange} />
        )) : <p className="text-gray-400 text-center py-4">No open tasks!</p>}
    </div>
);


const ActiveReorders: React.FC<{ reorderRequests: ReorderRequest[] }> = ({ reorderRequests }) => (
    <div className="space-y-4">
        {reorderRequests.length > 0 ? reorderRequests.map(req => (
             <div key={req.id} className="bg-red-900/50 border border-red-500 p-4 rounded-lg">
                <p className="font-bold text-white">Reorder Required: {req.productName}</p>
                <p className="text-sm text-gray-300">Quantity to reorder: {req.quantity}. Status: <span className="font-semibold">{req.status}</span></p>
            </div>
        )) : (
            <div className="bg-[var(--bg-card)] p-4 rounded-lg text-center text-gray-400">No active reorders.</div>
        )}
    </div>
);

const QuickActions: React.FC<{ openModal: (modal: ModalType) => void }> = ({ openModal }) => {
    const actions = [
        { label: 'Clock In/Out', icon: <ClockIcon className="mx-auto mb-2" />, modalType: 'clock-in-out' as const },
        { label: 'Report Issue', icon: <AlertTriangleIcon className="mx-auto mb-2" />, modalType: 'report-issue' as const },
        { label: 'Request Assistance', icon: <HelpCircleIcon className="mx-auto mb-2" />, modalType: 'request-assistance' as const },
        { label: 'Price Check', icon: <DollarSignIcon className="mx-auto mb-2" />, modalType: 'price-check' as const },
        { label: 'Apply for Leave', icon: <CalendarIcon className="mx-auto mb-2" />, modalType: 'apply-leave' as const, fullWidth: true },
    ];
    return (
        <div className="grid grid-cols-2 gap-4">
            {actions.map(action => (
                <button key={action.label} onClick={() => openModal({ type: action.modalType })} className={`bg-[var(--bg-card)] p-4 rounded-lg text-center hover:bg-[var(--bg-tertiary)] ${action.fullWidth ? 'col-span-2' : ''}`}>
                    {action.icon}
                    {action.label}
                </button>
            ))}
        </div>
    );
};

const StaffOnDuty: React.FC<{ employees: Employee[] }> = ({ employees }) => (
    <div className="space-y-3">
        {employees.slice(1, 3).map(emp => (
            <div key={emp.id} className="bg-[var(--bg-card)] p-3 rounded-lg flex items-center justify-between">
                <div className="flex items-center space-x-3">
                    <img className="h-8 w-8 rounded-full" src={`https://i.pravatar.cc/40?u=${emp.id}`} alt={emp.name}/>
                    <div><p className="font-semibold text-white text-sm">{emp.name}</p></div>
                </div>
                <div className="w-2 h-2 rounded-full bg-[var(--primary-orange)]"></div>
            </div>
        ))}
    </div>
);


const SmartCalendar: React.FC<{ schedules: Schedule; openModal: (m: ModalType) => void; }> = ({ schedules, openModal }) => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const timeSlots = Array.from({ length: 15 }, (_, i) => i + 8); // 8 AM to 10 PM
    const userSchedule = schedules['Sarah Johnson'] || [];
  
    const formatTime = (hour: number) => `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? 'am' : 'pm'}`;
  
    return (
      <div id="smart-calendar" className="bg-[var(--bg-card)] rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
                <button className="text-gray-400 hover:text-white"><ChevronsLeftIcon /></button>
                <h4 className="font-bold text-white text-lg">This Week</h4>
                <button className="text-gray-400 hover:text-white"><ChevronsRightIcon /></button>
            </div>
            <button onClick={() => openModal({type: 'smart-schedule'})} className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg text-sm">
                <BrainCircuitIcon className="w-4 h-4" />
                Smart Schedule
            </button>
        </div>
  
        <div className="grid grid-cols-8 text-center text-xs text-gray-400 font-bold border-b border-[var(--gray-dark)] pb-2">
          <div></div>
          {days.map(day => <div key={day}>{day}</div>)}
        </div>
  
        <div className="grid grid-cols-8">
            <div className="text-right text-xs text-gray-500 pr-2 border-r border-[var(--gray-dark)]">
                {timeSlots.map(hour => <div key={hour} className="h-12 flex items-center justify-end">{formatTime(hour)}</div>)}
            </div>
            {days.map(day => (
                <div key={day} className="relative border-r border-[var(--gray-dark)]">
                {timeSlots.map(hour => <div key={hour} className="h-12 border-b border-dashed border-[var(--bg-tertiary)]"></div>)}
                {userSchedule.filter(s => s.day === day).map(shift => {
                    const top = (shift.start - 8) * 3; // 3rem (h-12) per hour
                    const height = (shift.end - shift.start) * 3;
                    const bgColor = shift.type === 'meeting' ? 'bg-purple-500/80' : 'bg-orange-500/80';
                    return (
                        <div key={shift.id} style={{ top: `${top}rem`, height: `${height}rem`}} className={`absolute w-full px-1.5 py-1 text-left text-white rounded-md text-[10px] leading-tight group ${bgColor}`}>
                            <p className="font-bold truncate">{shift.title}</p>
                            <p>{formatTime(shift.start)} - {formatTime(shift.end)}</p>
                             {shift.type === 'shift' && (
                                <button onClick={() => openModal({type: 'request-sub', shift})} className="absolute bottom-1 right-1 bg-black/50 p-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity">
                                    <UsersIcon className="w-3 h-3 text-white" />
                                </button>
                            )}
                        </div>
                    );
                })}
                </div>
            ))}
        </div>
      </div>
    );
  };

const DashboardPage: React.FC<DashboardPageProps> = ({ tasks, reorderRequests, openModal, navigate, onTaskStatusChange, onTaskPriorityChange, schedules, employees }) => {
    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                <div>
                    <SmartCalendar schedules={schedules} openModal={openModal} />
                </div>
                <div>
                    <h3 className="text-xl font-bold text-white mb-4">Today's Tasks</h3>
                    <TasksList tasks={tasks} openModal={openModal} onTaskStatusChange={onTaskStatusChange} onTaskPriorityChange={onTaskPriorityChange} />
                </div>
                 <div>
                    <h3 className="text-xl font-bold text-white mb-4">Active Reorders</h3>
                    <ActiveReorders reorderRequests={reorderRequests} />
                </div>
            </div>
            <div className="space-y-8">
                 <div>
                    <h3 className="text-xl font-bold text-white mb-4">Quick Actions</h3>
                    <QuickActions openModal={openModal} />
                </div>
                <div>
                    <h3 className="text-xl font-bold text-white mb-4">Staff on Duty</h3>
                    <StaffOnDuty employees={employees}/>
                </div>
                <div>
                    <button onClick={() => navigate('database-page')} className="w-full bg-[var(--accent-orange)] hover:bg-[var(--orange-dark)] text-white font-bold py-3 px-4 rounded-lg">
                        View Database
                    </button>
                </div>
            </div>
        </div>
    );
};

export default DashboardPage;