
import React, { useState } from 'react';

type DBTab = 'customers' | 'sales' | 'inventory' | 'operations';

const DatabasePage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<DBTab>('customers');

    const tabs: { id: DBTab, label: string }[] = [
        { id: 'customers', label: 'Customers' },
        { id: 'sales', label: 'Sales & Revenue' },
        { id: 'inventory', label: 'Inventory & Orders' },
        { id: 'operations', label: 'Operations' },
    ];

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">Store Database Management</h2>
            <div className="bg-[var(--bg-card)] rounded-lg p-6">
                 <div className="border-b border-[var(--gray-dark)]">
                    <nav className="-mb-px flex space-x-8">
                         {tabs.map(tab => (
                            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`db-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm border-transparent text-gray-400 hover:text-white hover:border-gray-300 ${activeTab === tab.id ? 'active' : ''}`}>
                                {tab.label}
                            </button>
                        ))}
                    </nav>
                 </div>
                 <div className="mt-6">
                    <p className="text-gray-400">Database management interface for '{activeTab}' is coming soon.</p>
                 </div>
            </div>
        </div>
    );
};

export default DatabasePage;
