
import React from 'react';
import type { ModalType, FulfillmentOrder } from '../types';

const fulfillmentOrders: FulfillmentOrder[] = Array.from({ length: 100 }, (_, i) => {
    let status: 'pick' | 'pack' | 'ship';
    if (i <= 20) status = 'pick'; else if (i <= 70) status = 'pack'; else status = 'ship';
    return {
        id: `ORD-2025-${1000 + i + 1}`, customerName: ['John Smith', 'Jane Doe', 'Mike Chen'][i % 3], customerId: `CUST-${1000+i+1}`,
        orderDate: `2025-09-25`, priority: ['High', 'Medium', 'Low'][i % 3] as 'High' | 'Medium' | 'Low', itemCount: (i % 4) + 1, status,
        items: [{ name: 'iPhone 15 Case', qty: 1, img: `https://picsum.photos/100/100?random=${i}`}]
    };
});

const FulfillmentColumn: React.FC<{ title: string; orders: FulfillmentOrder[]; openModal: (modal: ModalType) => void }> = ({ title, orders, openModal }) => {
    return (
        <div className="bg-[var(--bg-card)] rounded-lg p-4 flex flex-col">
            <h3 className="font-bold text-white mb-4">{title} <span className="text-sm font-normal text-gray-400">({orders.length})</span></h3>
            <div className="space-y-3 overflow-y-auto custom-scrollbar flex-grow">
                {orders.map(order => (
                    <div key={order.id} onClick={() => alert("Order details not implemented.")} className="bg-[var(--bg-tertiary)] p-3 rounded-lg cursor-pointer hover:bg-[var(--gray-dark)]">
                        <div className="flex justify-between items-center">
                            <p className="font-bold text-white text-sm">{order.id}</p>
                            <span className={`text-xs px-2 py-1 rounded-full ${order.priority === 'High' ? 'bg-red-500/50 text-red-300' : 'bg-yellow-500/50 text-yellow-300'}`}>{order.priority}</span>
                        </div>
                        <p className="text-sm text-gray-300 mt-1">{order.customerName}</p>
                        <p className="text-xs text-gray-400">Items: {order.itemCount}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

const FulfillmentPage: React.FC<{ openModal: (modal: ModalType) => void }> = ({ openModal }) => {
    const toPick = fulfillmentOrders.filter(o => o.status === 'pick');
    const toPack = fulfillmentOrders.filter(o => o.status === 'pack');
    const toShip = fulfillmentOrders.filter(o => o.status === 'ship');
    
    return (
        <div className="flex flex-col h-[calc(100vh-12rem)]">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Fulfillment Center</h2>
            </div>
            <div className="flex-grow grid grid-cols-1 md:grid-cols-3 gap-6">
                <FulfillmentColumn title="To Pick" orders={toPick} openModal={openModal} />
                <FulfillmentColumn title="To Pack" orders={toPack} openModal={openModal} />
                <FulfillmentColumn title="To Ship" orders={toShip} openModal={openModal} />
            </div>
        </div>
    );
};

export default FulfillmentPage;
