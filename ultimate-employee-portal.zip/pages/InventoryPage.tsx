import React from 'react';
import type { InventoryItem, ModalType } from '../types';

interface InventoryPageProps {
    inventory: InventoryItem[];
    openModal: (modal: ModalType) => void;
}

const InventoryCard: React.FC<{ item: InventoryItem; onClick: () => void }> = ({ item, onClick }) => {
    const stockPercentage = (item.current_stock / item.max_capacity) * 100;
    const isLowStock = stockPercentage <= item.reorder_threshold * 100;
    let stockColor = 'bg-green-500';
    if (isLowStock) stockColor = 'bg-red-500';
    else if (stockPercentage <= 50) stockColor = 'bg-yellow-500';

    return (
        <div onClick={onClick} className="bg-[var(--bg-card)] p-4 rounded-lg cursor-pointer hover:bg-[var(--bg-tertiary)] transition-colors duration-200">
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-white">{item.name}</p>
                    <p className="text-xs text-gray-400">{item.product_code}</p>
                </div>
                <span className="text-lg font-bold">
                    {item.current_stock} <span className="text-sm font-normal text-gray-400">/ {item.max_capacity}</span>
                </span>
            </div>
            <div className="w-full bg-[var(--bg-tertiary)] rounded-full h-2.5 mt-4">
                <div className={`${stockColor} h-2.5 rounded-full`} style={{ width: `${stockPercentage}%` }}></div>
            </div>
            {isLowStock && (
                <div className="mt-3 border-t border-[var(--gray-dark)] pt-3 text-xs text-red-400 space-y-1">
                    <p><strong className="text-gray-300">Min. Reorder Qty:</strong> {item.min_order_quantity} units</p>
                    <p><strong className="text-gray-300">Supplier ID:</strong> {item.supplier_id}</p>
                </div>
            )}
        </div>
    );
};

const InventoryPage: React.FC<InventoryPageProps> = ({ inventory, openModal }) => {
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Inventory Dashboard</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {inventory.map(item => <InventoryCard key={item.product_code} item={item} onClick={() => openModal({ type: 'inventory-detail', item })} />)}
            </div>
        </div>
    );
};

export default InventoryPage;