
import React from 'react';

interface LoginPageProps {
    onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        onLogin();
    };

    return (
        <div id="login-page" className="page">
            <div className="flex flex-col items-center justify-center min-h-screen p-4">
                <div className="w-full max-w-md">
                    <div className="text-center mb-8">
                        <h1 className="text-3xl font-bold text-white">Ultimate Employee Portal</h1>
                        <p className="text-gray-400 mt-2">Welcome back! Please sign in.</p>
                    </div>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">Email Address</label>
                            <input
                                type="email"
                                id="email"
                                defaultValue="sarah.johnson@company.com"
                                className="w-full px-4 py-3 rounded-lg text-white placeholder-gray-500 focus:outline-none form-input"
                            />
                        </div>
                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                            <input
                                type="password"
                                id="password"
                                defaultValue="store123"
                                className="w-full px-4 py-3 rounded-lg text-white placeholder-gray-500 focus:outline-none form-input"
                            />
                        </div>
                        <div>
                            <button type="submit" className="w-full bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-3 px-4 rounded-lg">
                                Sign In
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
