import React, { useState } from 'react';
import type { ModalType, Payslip } from '../types';

// Mock data
const payslipData: Payslip[] = Array.from({ length: 36 }, (_, i) => {
    const date = new Date(new Date().getFullYear(), new Date().getMonth() - i, 1);
    const month = date.toLocaleString('default', { month: 'long' });
    const year = date.getFullYear();
    const base = 3000 + Math.random() * 200, commission = 200 + Math.random() * 150, overtime = 50 + Math.random() * 150;
    const earnings = { basic: base, overtime, commission, meal: 100, transport: 50};
    const totalEarnings = Object.values(earnings).reduce((a, b) => a + b, 0);
    const tax = totalEarnings * 0.15, pf = totalEarnings * 0.06, insurance = 50;
    const deductions = { tax, pf, insurance };
    const totalDeductions = tax + pf + insurance;

    return {
        id: 36 - i, month, year, earnings, deductions,
        attendance: { worked: 160 + Math.floor(Math.random()*12), overtime: 8 + Math.floor(Math.random()*5), leaves: Math.floor(Math.random()*3)},
        gross: totalEarnings, totalDeductions, net: totalEarnings - totalDeductions
    };
}).sort((a,b) => b.id - a.id);

const years = [...new Set(payslipData.map(p => p.year))].sort((a,b) => b - a);
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];


const PayslipDetails: React.FC<{ payslip: Payslip; openModal: (modal: ModalType) => void }> = ({ payslip, openModal }) => {
    return (
        <>
            <div className="border-b border-[var(--gray-dark)] pb-4 mb-4 flex justify-between items-center">
                <div>
                    <h3 className="text-xl font-bold text-white">Payslip for {payslip.month} {payslip.year}</h3>
                    <p className="text-sm text-gray-400">Net Pay: <span className="text-lg font-bold text-[var(--accent-orange)]">${payslip.net.toFixed(2)}</span></p>
                </div>
                <div className="flex gap-2">
                   <button className="bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-2 px-4 rounded-lg">Download PDF</button>
                   <button onClick={() => alert("Raise Query not implemented.")} className="bg-[var(--gray-dark)] hover:bg-[var(--gray-medium)] text-white font-bold py-2 px-4 rounded-lg">Raise Query</button>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div>
                    <h4 className="font-bold text-white mb-2">Earnings</h4>
                    <div className="bg-[var(--bg-tertiary)] p-3 rounded-lg space-y-2">
                        {/* FIX: Cast value to number to use toFixed, as Object.entries may not infer the type correctly. */}
                        {Object.entries(payslip.earnings).map(([key, value]) => <div key={key} className="flex justify-between text-sm"><span>{key.charAt(0).toUpperCase() + key.slice(1)}</span><span>${(value as number).toFixed(2)}</span></div>)}
                        <div className="flex justify-between font-bold border-t border-gray-600 pt-2 mt-2"><span>Gross Earnings</span><span>${payslip.gross.toFixed(2)}</span></div>
                    </div>
                </div>
                <div>
                    <h4 className="font-bold text-white mb-2">Deductions</h4>
                     <div className="bg-[var(--bg-tertiary)] p-3 rounded-lg space-y-2">
                        {/* FIX: Cast value to number to use toFixed, as Object.entries may not infer the type correctly. */}
                        {Object.entries(payslip.deductions).map(([key, value]) => <div key={key} className="flex justify-between text-sm"><span>{key.charAt(0).toUpperCase() + key.slice(1)}</span><span>-${(value as number).toFixed(2)}</span></div>)}
                        <div className="flex justify-between font-bold border-t border-gray-600 pt-2 mt-2"><span>Total Deductions</span><span>-${payslip.totalDeductions.toFixed(2)}</span></div>
                    </div>
                </div>
            </div>
        </>
    );
}


const PayslipPage: React.FC<{ openModal: (modal: ModalType) => void }> = ({ openModal }) => {
    const [selectedYear, setSelectedYear] = useState(years[0]);
    const [selectedMonth, setSelectedMonth] = useState('all');
    
    const filteredPayslips = payslipData.filter(p => p.year === selectedYear && (selectedMonth === 'all' || p.month === selectedMonth));
    const [activePayslip, setActivePayslip] = useState<Payslip | undefined>(filteredPayslips[0]);

    React.useEffect(() => {
        const newFiltered = payslipData.filter(p => p.year === selectedYear && (selectedMonth === 'all' || p.month === selectedMonth));
        setActivePayslip(newFiltered[0]);
    }, [selectedYear, selectedMonth]);

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">Payslip Portal</h2>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div className="lg:col-span-1 bg-[var(--bg-card)] rounded-lg p-4">
                     <div className="flex gap-2 mb-4">
                        <select value={selectedYear} onChange={e => setSelectedYear(parseInt(e.target.value))} className="form-input w-full p-2 rounded-md">
                            {years.map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                        <select value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="form-input w-full p-2 rounded-md">
                            <option value="all">All</option>
                            {months.map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                    </div>
                    <h3 className="font-bold text-white mb-4">History</h3>
                    <div className="space-y-2">
                        {filteredPayslips.map(p => (
                            <button key={p.id} onClick={() => setActivePayslip(p)} className={`w-full text-left p-3 rounded-lg ${activePayslip?.id === p.id ? 'bg-[var(--bg-tertiary)] text-white' : 'hover:bg-[var(--bg-tertiary)]'}`}>
                                {p.month} {p.year}
                            </button>
                        ))}
                    </div>
                </div>
                <div className="lg:col-span-3 bg-[var(--bg-card)] rounded-lg p-6">
                    {activePayslip ? <PayslipDetails payslip={activePayslip} openModal={openModal} /> : <p className="text-center text-gray-400">No payslip selected.</p>}
                </div>
            </div>
        </div>
    );
};

export default PayslipPage;