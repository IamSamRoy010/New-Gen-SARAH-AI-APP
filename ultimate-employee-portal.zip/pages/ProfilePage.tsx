
import React, { useState } from 'react';

type ProfileTab = 'personal-info' | 'leave-management' | 'performance-settings';

const userProfile = {
    fullName: 'Sarah Johnson', employeeId: 'EMP12345', phone: '555-123-4567', email: 'sarah.johnson@company.com',
    emergencyContact: { name: 'John Johnson', relationship: 'Father', phone: '555-987-6543' }, address: '123 Main St, Anytown, USA',
    leave: { requests: [ { type: 'Sick', date: '2025-09-15', days: 1, status: 'Approved' }, { type: 'Personal', date: '2025-08-20', days: 2, status: 'Approved' } ] }
};

const PersonalInfoTab: React.FC = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div><h4 className="font-bold text-white mb-2">Contact Details</h4><div className="bg-[var(--bg-tertiary)] p-3 rounded-lg text-sm space-y-1"><p>Phone: {userProfile.phone}</p><p>Email: {userProfile.email}</p></div></div>
        <div><h4 className="font-bold text-white mb-2">Emergency Contact</h4><div className="bg-[var(--bg-tertiary)] p-3 rounded-lg text-sm space-y-1"><p>{userProfile.emergencyContact.name} ({userProfile.emergencyContact.relationship})</p><p>{userProfile.emergencyContact.phone}</p></div></div>
        <div className="md:col-span-2"><h4 className="font-bold text-white mb-2">Address</h4><div className="bg-[var(--bg-tertiary)] p-3 rounded-lg text-sm">{userProfile.address}</div></div>
    </div>
);

const LeaveManagementTab: React.FC = () => (
    <div>
        <h4 className="font-bold text-white mb-2">Leave History</h4>
        <div className="space-y-2">
         {userProfile.leave.requests.map((req, i) => (
            <div key={i} className="bg-[var(--bg-tertiary)] p-3 rounded-lg flex justify-between items-center text-sm">
                <div><p className="font-semibold">{req.type} Leave ({req.days} day{req.days > 1 ? 's' : ''})</p><p className="text-xs text-gray-400">Date: {req.date}</p></div>
                <span className="text-xs font-bold text-green-400">{req.status}</span>
            </div>
         ))}
        </div>
    </div>
);

const PerformanceSettingsTab: React.FC = () => (
    <div>
        <h4 className="font-bold text-white mb-2">Achievements</h4>
        <div className="flex gap-4">
            <div className="bg-yellow-500/20 text-yellow-300 p-2 rounded-lg text-xs">Top Seller - Q3</div>
            <div className="bg-blue-500/20 text-blue-300 p-2 rounded-lg text-xs">Perfect Attendance</div>
        </div>
    </div>
);

const ProfilePage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<ProfileTab>('personal-info');

    const tabs: { id: ProfileTab, label: string }[] = [
        { id: 'personal-info', label: 'Personal Info' },
        { id: 'leave-management', label: 'Leave Management' },
        { id: 'performance-settings', label: 'Performance & Settings' },
    ];
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1 bg-[var(--bg-card)] rounded-lg p-6 text-center h-min">
                 <img className="h-24 w-24 rounded-full mx-auto mb-4" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=256" alt="User profile"/>
                 <h3 className="text-xl font-bold text-white">Sarah Johnson</h3>
                 <p className="text-gray-400">Associate</p>
                 <button className="mt-4 w-full bg-[var(--bg-tertiary)] hover:bg-[var(--gray-dark)] text-sm py-2 rounded-lg">Upload Photo</button>
            </div>
            <div className="lg:col-span-3 bg-[var(--bg-card)] rounded-lg p-6">
                 <div className="border-b border-[var(--gray-dark)]">
                    <nav className="-mb-px flex space-x-8">
                        {tabs.map(tab => (
                            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`profile-tab whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm border-transparent text-gray-400 hover:text-white hover:border-gray-300 ${activeTab === tab.id ? 'active' : ''}`}>
                                {tab.label}
                            </button>
                        ))}
                    </nav>
                 </div>
                 <div className="mt-6">
                    {activeTab === 'personal-info' && <PersonalInfoTab />}
                    {activeTab === 'leave-management' && <LeaveManagementTab />}
                    {activeTab === 'performance-settings' && <PerformanceSettingsTab />}
                 </div>
            </div>
        </div>
    );
};

export default ProfilePage;
