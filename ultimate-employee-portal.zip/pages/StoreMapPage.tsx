
import React, { useEffect, useRef } from 'react';

const StoreMapPage: React.FC = () => {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (typeof (window as any).THREE === 'undefined' || !containerRef.current) return;

        const THREE = (window as any).THREE;
        const container = containerRef.current;
        let scene: any, camera: any, renderer: any;

        const init = () => {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x1a1a1a);
            camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(container.clientWidth, container.clientHeight);
            container.innerHTML = '';
            container.appendChild(renderer.domElement);
            
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
            scene.add(ambientLight);
            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(10, 15, 5);
            scene.add(directionalLight);

            const floorGeo = new THREE.PlaneGeometry(50, 50);
            const floorMat = new THREE.MeshStandardMaterial({ color: 0x404040 });
            const floor = new THREE.Mesh(floorGeo, floorMat);
            floor.rotation.x = -Math.PI / 2;
            scene.add(floor);

            const aisleGeo = new THREE.BoxGeometry(2, 5, 12);
            const aisleMat = new THREE.MeshStandardMaterial({ color: 0x666666 });
            
            for (let i = -2; i <= 2; i++) {
                if (i === 0) continue;
                const aisle = new THREE.Mesh(aisleGeo, aisleMat);
                aisle.position.set(i * 8, 2.5, 0);
                scene.add(aisle);
            }

            camera.position.set(0, 15, 25);
            camera.lookAt(0, 0, 0);

            animate();
        };

        const animate = () => {
            if (!renderer) return;
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        };

        init();
        
        const onResize = () => {
            if(container) {
                camera.aspect = container.clientWidth / container.clientHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(container.clientWidth, container.clientHeight);
            }
        };

        window.addEventListener('resize', onResize);

        return () => {
            window.removeEventListener('resize', onResize);
            renderer?.dispose();
            if (container) {
                container.innerHTML = '';
            }
        };
    }, []);

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">3D Store Map</h2>
            <div className="bg-[var(--bg-card)] rounded-xl p-4 flex flex-col">
                <h3 className="text-lg font-bold text-white mb-4">Interactive Store Layout</h3>
                <div ref={containerRef} className="w-full h-96 bg-[var(--bg-secondary)] rounded-lg cursor-grab active:cursor-grabbing"></div>
            </div>
        </div>
    );
};

export default StoreMapPage;
