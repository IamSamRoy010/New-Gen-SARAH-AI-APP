
import React, { useState, useMemo } from 'react';
import type { ModalType, TrainingModule } from '../types';

// Mock data updated with new fields for certificates
const trainingModules: TrainingModule[] = [
    { id: 'cs', title: 'Customer Service Excellence', description: 'Master the art of customer interaction, conflict resolution, and building loyalty.', progress: 100, completed: true, completionDate: '2025-08-15', level: 'Advanced', certificateId: 'CERT-CS-101', score: 95, instructor: 'Jane Doe' },
    { id: 'sc', title: 'Safety & Compliance', description: 'Learn essential safety protocols and ensure a secure store environment for everyone.', progress: 100, completed: true, completionDate: '2025-07-20', level: 'Intermediate', certificateId: 'CERT-SC-102', score: 98, instructor: 'John Smith' },
    { id: 'ai', title: 'AI-Powered Sales Scenarios', description: 'Practice upselling and customer handling with an advanced AI-powered role-playing partner.', progress: 10, completed: false, special: true, level: 'Expert', certificateId: 'CERT-AI-103', score: 0, instructor: 'SARAH AI' },
    { id: 'pk', title: 'iPhone 17 Pro Max Deep Dive', description: 'Become an expert on the features, specs, and selling points of our flagship product.', progress: 40, completed: false, level: 'Intermediate', certificateId: 'CERT-PK-104', score: 0, instructor: 'Mike Chen' },
    { id: 'ts', title: 'Point of Sale Mastery', description: 'Efficiently use the portal and POS systems for seamless transactions and inventory management.', progress: 15, completed: false, level: 'Basic', certificateId: 'CERT-TS-105', score: 0, instructor: 'Emily Taylor' },
    { id: 'ld', title: 'Leadership Development', description: 'A comprehensive program for aspiring team leads covering mentoring, shift management, and motivation.', progress: 0, completed: false, level: 'Advanced', certificateId: 'CERT-LD-106', score: 0, instructor: 'David Lee' },
];

const TrainingDashboard: React.FC = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-[var(--bg-card)] p-4 rounded-lg">
            <h4 className="font-bold text-white mb-2">Overall Progress</h4>
            <div className="w-full bg-[var(--bg-tertiary)] rounded-full h-4"><div className="bg-[var(--primary-orange)] h-4 rounded-full" style={{width: '45%'}}></div></div>
            <p className="text-center text-sm mt-2">45% Complete</p>
        </div>
        <div className="bg-[var(--bg-card)] p-4 rounded-lg">
            <h4 className="font-bold text-white mb-2">Skill Matrix</h4>
            <ul className="text-xs text-gray-400 list-disc list-inside">
                <li>Sales: <span className="font-semibold text-green-400">Proficient</span></li>
                <li>Support: <span className="font-semibold text-yellow-400">Intermediate</span></li>
                 <li>Leadership: <span className="font-semibold text-gray-500">Beginner</span></li>
            </ul>
        </div>
        <div className="bg-[var(--bg-card)] p-4 rounded-lg">
            <h4 className="font-bold text-white mb-2">Upcoming Sessions</h4>
            <p className="text-xs text-gray-400">Oct 5, 10am: Advanced Sales Techniques</p>
            <p className="text-xs text-gray-400">Oct 12, 2pm: Q4 Product Lineup</p>
        </div>
    </div>
);

const levelStyles: Record<TrainingModule['level'], string> = {
    'Basic': 'bg-blue-500/50 text-blue-300',
    'Intermediate': 'bg-green-500/50 text-green-300',
    'Advanced': 'bg-yellow-500/50 text-yellow-300',
    'Expert': 'bg-purple-500/50 text-purple-300',
};

const CertificateGallery: React.FC<{ certificates: TrainingModule[], openModal: (m: ModalType) => void }> = ({ certificates, openModal }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOrder, setSortOrder] = useState<'recent' | 'alphabetical'>('recent');

    const filteredAndSortedCerts = useMemo(() => {
        return certificates
            .filter(cert => cert.title.toLowerCase().includes(searchTerm.toLowerCase()))
            .sort((a, b) => {
                if (sortOrder === 'alphabetical') {
                    return a.title.localeCompare(b.title);
                }
                // Default to 'recent'
                return new Date(b.completionDate!).getTime() - new Date(a.completionDate!).getTime();
            });
    }, [certificates, searchTerm, sortOrder]);

    return (
        <div>
             <h3 className="text-xl font-bold text-white mt-8 mb-4">My Certificates</h3>
             <div className="flex flex-col md:flex-row gap-4 mb-4">
                 <input 
                    type="text" 
                    placeholder="Search certificates..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="form-input w-full md:w-1/2 p-2 rounded-md"
                />
                <select 
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value as 'recent' | 'alphabetical')}
                    className="form-input w-full md:w-auto p-2 rounded-md"
                >
                    <option value="recent">Sort by Most Recent</option>
                    <option value="alphabetical">Sort Alphabetically</option>
                </select>
             </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredAndSortedCerts.map(cert => (
                    <button key={cert.id} onClick={() => openModal({ type: 'view-certificate', module: cert })} className="bg-[var(--bg-card)] p-4 rounded-lg text-left hover:bg-[var(--bg-tertiary)] transition-colors group">
                        <p className="font-bold text-white text-sm mb-1 group-hover:text-[var(--primary-orange)]">{cert.title}</p>
                        <p className="text-xs text-gray-400 mb-2">Completed: {cert.completionDate}</p>
                        <span className={`text-xs px-2 py-1 rounded-full font-semibold ${levelStyles[cert.level]}`}>{cert.level}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

const TrainingHubPage: React.FC<{ openModal: (modal: ModalType) => void }> = ({ openModal }) => {
    const completedModules = trainingModules.filter(m => m.completed);
    const inProgressModules = trainingModules.filter(m => !m.completed);

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-6">Training Hub</h2>
            <TrainingDashboard />

            <h3 className="text-xl font-bold text-white mb-4">Available Courses</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {inProgressModules.map(module => (
                    <div key={module.id} className={`bg-[var(--bg-card)] p-6 rounded-lg ${module.special ? 'border border-purple-500' : ''}`}>
                        <h3 className="font-bold text-white mb-2">{module.title}</h3>
                        <p className="text-sm text-gray-400 mb-4 h-12">{module.description}</p>
                        <div className="w-full bg-[var(--bg-tertiary)] rounded-full h-2.5 mb-2"><div className="bg-[var(--primary-orange)] h-2.5 rounded-full" style={{width: `${module.progress}%`}}></div></div>
                        <p className="text-xs text-gray-300 mb-4">{module.progress}% Complete</p>
                        <button onClick={() => alert("View Course not implemented.")} className="mt-4 text-sm bg-[var(--primary-orange)] hover:bg-[var(--accent-orange)] text-white font-bold py-2 px-4 rounded-lg">
                            {module.progress > 0 ? 'Continue Course' : 'Start Course'}
                        </button>
                    </div>
                ))}
            </div>

            <CertificateGallery certificates={completedModules} openModal={openModal} />
        </div>
    );
};

export default TrainingHubPage;
