
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  console.warn("Gemini API key not found in environment variables. Using a placeholder. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_HERE" });

interface ImagePart {
    inlineData: {
        mimeType: string;
        data: string;
    };
}

export const generateContentStream = async (prompt: string, image?: ImagePart) => {
    try {
        const contents = image ? { parts: [image, { text: prompt }] } : { parts: [{ text: prompt }] };
        
        const response = await ai.models.generateContentStream({
            model: "gemini-2.5-flash",
            contents: contents,
            config: {
                systemInstruction: "You are SARAH, a helpful, friendly, and slightly witty AI assistant for retail employees. You are embedded in the 'Ultimate Employee Portal'. Your primary goal is to provide concise, accurate, and actionable information. When asked about tasks, inventory, or procedures, be direct. You can also handle general knowledge questions. Keep responses brief and to the point.",
            }
        });
        
        return response;
    } catch (error) {
        console.error("Error generating content with Gemini:", error);
        throw new Error("Failed to get a response from the AI assistant.");
    }
};
